﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;
using XF.MVVMBasic.App.Model;
using System.Threading.Tasks;
using XF.MVVMBasic.App.Helpers;

namespace XF.MVVMBasic.App.ViewModel
{
    public class AlunoViewModel
    {
       
        private const string CONTROLLER = "Aluno";
               
        public List<Aluno> GetAlunoAsync()
        {
            try
            {
                var client = new ApiHelper().ObterHttClient();
                string url = new ApiHelper().ObterUrl(CONTROLLER);

                var response =  client.GetStringAsync(url).Result;
                var lista = JsonConvert.DeserializeObject<List<Aluno>>(response);

                return lista;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        } 

    }
}
